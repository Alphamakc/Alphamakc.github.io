#Repl.it
#Text Adventure
#Jonathan Pellior
#Angel Toral
#Tia Dzafic
money = 300
stage = "intro"

def AbilitySet1():
  AbilitySet1 = input("You Feel the Magicks Coursing within you, and you now must move the strands into the magick weaves.  How do you weave your magick?  Type 'thunder' to cast Thunder Wave, type 'inspire' to give Bardic Inspiration, or type 'other' to view your other ability sets (Items, Weapons, and the like.): ")
def AbilitySet2():
  print("")
def intro():
  global stage
  print("A tall man coated in scales with a snout on his face, scarred by the years, but with a light, warm smile on his face walked the streets of Circuit Lake Town.  His metal peg-leg was scraping with each step on the cobbled streets.  It was about evening, and there was a slight drizzle of rainfall.  You, Rel Gerken XIV walk proudly down to the Inn with a sign saying: “Circuit Lake Inn”")
  stage = "AskForDrink"
#This is the section where you first ask for a drink
def AskForDrink():
  global stage
  global money
  AskForDrink = input("Do you ask for a drink, or sit at the bar? Type 'drink' to drink or type 'bar' to wait: " )
  print("")
  if AskForDrink == "drink" or AskForDrink == "Drink":
    print("According to your input, You get a drink. You start getting sleepy, you see a shadow in the corner of your eye as you pass out. ")
    stage = "WakeUp"
  elif AskForDrink == "bar" or AskForDrink == "Bar":
    print("According to your input, You sit at the bar, and ask for a nice meal.  You pay 5 copper pieces.  And a man walks in.")
    stage = "Drew1"
    money = 295
  else:
    print("[SYNTAX ERROR, PLEASE CONTACT A NETWORK ADMINISTRATOR FOR MORE DETAILS]")
#this is where you meet Drew Amblecrown
def Drew1():
  global stage
  Drew1 = input("A man walked up to the bar, he wore green robes, and asked: ' May I sit next to you sir? ' Type 'sure' to let him sit here, type 'no' to wave him off: ")
  if Drew1 == "sure" or Drew1 == "Sure":
    print("You say: 'Sure'  ")
    stage = "DrewStory1"
  elif Drew1 == "no" or Drew1 == "No":
    print("You tell Drew, ' No thank you. ' Drew insists that he buys you a drink.")
    stage = "DrewInsists1"
def DrewStory1():
  DrewStory1 = input("Drew Tells you a story, and you listen for a hour or so, you get the oporotunity to tell a story to Drew.  Type 'tale' to tell a bardic tale, type 'fable' to tell a bardic fable, or type 'personal' to tell a tale of your adventures: ")
  if DrewStory1 == "personal" or DrewStory1 == "Personal":
    print("")
  if DrewStory1 == "fable" or DrewStory1 == "Fable":
    print("")
  if DrewStory1 == "tale" or DrewStory1 == "Tale":
    print("")
def DrewInsists1():
  global stage
  DrewInsists1 = input("Drew buys you a drink.  Type 'story' to tell him a tale, type 'duel' to duel him, or type 'room' to head to your room.")
  if DrewInsists1 == "duel" or DrewInsists1 == "Duel":
    print("Drew buys you a drink, and you, after downing it, buy him a drink.  He drinks it and you say ' I wish to duel you, as a test to show your strength. '")
  elif DrewInsists1 == "story" or DrewInsists1 == "Story":
    print("You tell Drew a tale of your travels across the lands, and after an hour of chat, you get sleepy.")
#this is where you wake up after having too many drinks (Everything beneath this is The WakeUp Stage)
def WakeUp():
  global stage
  WakeUp = input("You stir in your sleep.  Once you have awaken, what do you do, as you notice two City Watch walk into the bar?  Type 'watch' to watch the Guards, or type 'drink' to get another drink and fall back asleep: ")
  if WakeUp == "drink" or WakeUp == "Drink":
    print("You pass out on the floor.  After what seems to be an eternity, you hear a man screaming as he gets dragged out the door by the city watch.")
    stage = "Follow1"
  elif WakeUp == "watch" or WakeUp == "Watch":
    print("You watch the two City Watchmen as they go to a cloaked man in the corner of the tavern.  The Watchmen start to grab at the man, and drag him as he screams out the door.")
    stage = "Follow1"
  else:
    print("[SYNTAX ERROR, PLEASE CONTACT A NETWORK ADMINISTRATOR FOR MORE DETAILS]")
#this is the option where you may either follow the City Watch or stay at the bar
def Follow1():
  global stage
  Follow1 = input("Do you follow?  Type 'yes' to follow or type 'no' to stay at the inn: ")
  if Follow1 == "yes" or Follow1 == "Yes":
    print("You stealthily follow the guards as they go towards the City Court.")
    print("You follow the guards up until you are behind the City Court, towards the prison in the back.  The Guards enter through there.")
    stage = "Enter1"
  elif Follow1 == "no" or Follow1 == "No":
    print("You stay at the inn, and you get a room to stay the night.  As you dindle towards sleep as you lay in bed, at the room you just paid for, you hear light rainfall.")
    stage = "Stay1"
  else:
    print("[SYNTAX ERROR, PLEASE CONTACT A NETWORK ADMINISTRATOR FOR MORE DETAILS]")
def Stay1():
  print("You stay at the inn for the rest of your pitiful existance, have fun!")
  stage = "Quit"
#this is the section where you may first enter the City Hall
def Enter1():
  global stage
  Enter1 = input("How do you enter the City Court?  Type 'window' to enter through the barred window, type 'back' to enter through the back door, or type 'front' to enter through the main enterance: ")
  if Enter1 == "window" or Enter1 == "Window":
    print("You attempt to enter through the barred window to one of the cells.  You are unsuccessful, you can either use an item on your person to get through, or you may try another enterance.")
    stage = "EnterAgain1"
  elif Enter1 == "back" or Enter1 == "Back":
    print("You walk through the back door of the prison, (which the guards forgot to lock) and you see them drag him through another door into what appears to have been the Main Court.")
  elif Enter1 == "front" or Enter1 == "Front":
    print("You enter through the front door, and two guards are on the other side.  One walks up and says: 'This is a restricted area we are going to need to take you to the cells.' ")
    stage = "EnterFront1"
  else:
    print("[SYNTAX ERROR, PLEASE CONTACT A NETWORK ADMINISTRATOR FOR MORE DETAILS]")
#This is the section where you failed to open the window.
def EnterAgain1():
  global stage
  EnterAgain1 = input("You have a knife on you.  Type 'cut' to try to cut through the bars, type 'front' to enter through the front, or type 'back' to enter through the back door: ")
  if EnterAgain1 == "cut" or EnterAgain1 == "Cut":
    print("You successfully cut through the bars with your knife, although the blade is ruined.  You cannot use it any more.")
    stage = "EnterWindow1"
  elif EnterAgain1 == "front" or EnterAgain1 == "Front":
    print("You enter through the front door, and two guards are on the other side.  One walks up and says: 'This is a restricted area we are going to need to take you to the cells.' ")
    stage = "EnterFront1"
  elif EnterAgain1 == "back" or EnterAgain1 == "Back":
    print("You walk through the back door of the prison, (which the guards forgot to lock) and you see them drag him through another door into what appears to have been the Main Court.")
    stage = "EnterBack1"
  else:
    print("[SYNTAX ERROR, PLEASE CONTACT A NETWORK ADMINISTRATOR FOR MORE DETAILS]")
#This is the section where you make the decision to enter through the front (but you fail because of the guards.)
def EnterFront1():
  global stage
  EnterFront1 = input("The Guards take you to the back room, and throw you in a cell to rot for eternity.  Type 'play' to play again, or type 'end' to quit: ")
  if EnterFront1 == "play" or EnterFront1 == "Play":
    print("So then, let's restart.")
    stage = "intro"
  elif EnterFront1 == "end" or EnterFront1 == "End":
    print("We're stuck here for eternity.  Have fun")
    stage = "Quit"
  else:
    print("[SYNTAX ERROR, PLEASE CONTACT A NETWORK ADMINISTRATOR FOR MORE DETAILS]")
#this is where you enter the back of the place.
def EnterBack1():
  global stage
  EnterBack1 = input("You see a row of prison cells, some with people in them, but most are empty.  As you look down the corridor, you see sans (You feel like you're gonna have a bad time), rusty bars and a moldy door at the end of the hallway.  Type 'break' to break off one of the bars, type 'door' to try the moldy door, or type 'cell' to observe a cell: ")
  if EnterBack1 == "break" or EnterBack1 == "Break":
    print("You walk over to one of the cells, and attempt to pry off one of the weak, rusty bars.  You succeed and in doing so you now have a metal bar.")
    stage = "MetalBar1"
  elif EnterBack1 == "door" or EnterBack1 == "Door":
    print("You walk to the door leading to the main room, and the grate at the top of the door was shut.  You try the handle, but it is locked.")
    stage = "MoldyDoor1"
  elif EnterBack1 == "cell" or EnterBack1 == "Cell":
    print("You walk over to one of the cells, and see a man lying on the floor, beaten and bloodied.  You lean forward to get a closer look, and he leaps at you and grabs you collar, bashing your face on the bars.  The light faded from your eyes, as you, Rel Gerken XIV, die.")
    stage = "Quit"
  else:
    print("[SYNTAX ERROR, PLEASE CONTACT A NETWORK ADMINISTRATOR FOR MORE DETAILS]")
#this is the point in which you break through the window with your knife.
def EnterWindow1():
  global stage
  EnterWindow1 = input("You enter the window and are met with a cell.  The cell has rusty iron bars, and there is a cage that contains a small rodent in the cell.  Type 'cage' to open the cage, or type 'bar' to pry open a bar: ")
  if EnterWindow1 == "cage" or EnterWindow1 == "Cage":
    print("You open the latch to the cage and the small, starving rodent comes out.  It looks at you with hopeful eyes, and it starts to morph into a disgusting half orc, hobgoblin mixture.  She thanks you, and asks what she can do to repay you.")
    stage = "NightDezgraza1"
  elif EnterWindow1 == "bar" or EnterWindow1 == "Bar":
    print("You pry out one of the bars, and step through into a hallway.  You have obtained a rusty bar as well.  You look down the hallway, and one side appears to be the exit, and one leads into the court")
    stage = "EnterThroughCell1"
  else:
    print("[SYNTAX ERROR, PLEASE CONTACT A NETWORK ADMINISTRATOR FOR MORE DETAILS]")
  #This is the point where you meet Night Desgraza
def NightDezgraza1():
  global stage
  NightDezgraza1 = input(" ' My name is Night Dezgraza, thank you for saving me.  I surely would have rotted in there.  What is your name? ' Type 'rel' to say your name is Rel, or type 'night' to say your name is Night too, to mask your identity: ")
  if NightDezgraza1 == "rel" or NightDezgraza1 == "Rel":
    print("You reply, ' Hello, my name is Rel Gerken The Fourteenth.  Now is not a time for introductions though.  What have you seen of the man who was dragged in here moments ago? '")
    print("")
    print(" ' I saw him get dragged into the room ahead, and I believe he's being put on trial.  We should help. '")
    stage = "EnterCourt1"
  if NightDezgraza1 == "night" or MightDezgraza1 == "Night":
    print("")

  
#This is the Quit Screen!
def Quit():
  global stage
  print("It was at this moment that you realize your mistakes, and that you should have chosen a seperate path.")
  stage = "intro"
#This is where everything starts

while(1):
  if stage == "intro":
    print("")
    intro()
  elif stage == "AskForDrink":
    print("")
    AskForDrink()
  elif stage == "Stay1":
    print("")
    Stay1()
  elif stage == "Drew1":
    print("")
    Drew1()
  elif stage == "WakeUp":
    print("")
    WakeUp()
  elif stage == "Follow1":
    print("")
    Follow1()
  elif stage == "Enter1":
    print("")
    Enter1()
  elif stage == "EnterAgain1":
    print("")
    EnterAgain1()
  elif stage == "EnterFront":
    print("")
    EnterFront1()
  elif stage == "EnterBack1":
    print("")
    EnterBack1()
  elif stage == "EnterWindow1":
    print("")
    EnterWindow1()
  elif stage == "NightDezgraza1":
    print("")
    NightDezgraza1()
  elif stage == "Quit":
    print("")
    Quit()